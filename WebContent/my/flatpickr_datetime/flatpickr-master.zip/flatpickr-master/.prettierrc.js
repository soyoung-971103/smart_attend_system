module.exports =  {
    trailingComma:  'es5',
  };